import sys
is_py2 = sys.version[0] == '2'
if is_py2:
    from Queue import Queue
    from Queue import Empty
    from Queue import Full
else:
    from queue import Queue
    from queue import Full
from threading import Thread
import time
import random
from PIL import Image
from .socket_util import *
import io
import sys
import numpy as np
import logging

from .protoc import *





def threaded(fn):
    def wrapper(*args, **kwargs):
        thread = Thread(target=fn, args=args, kwargs=kwargs)
        thread.setDaemon(True)
        thread.start()

        return thread
    return wrapper


class ImageData():

    def __init__(self):

        self.raw_rgb = []
        self.rgb = []
        self.depth = []
        self.scene_seg = []


class DataStream(object):

    def __init__(self,image_x=640,image_y=480):
        self._data_buffer = Queue(1)
        self._image_x = image_x
        self._image_y = image_y

        self._socket = 0
        self._running = True



    def _read_image(self,imagedata,pointer):


        # read width ( 4 bytes )
        width = struct.unpack('<L',imagedata[pointer:(pointer+4)])[0]

        pointer +=4
        # read height ( 4 bytes )
        height = struct.unpack('<L',imagedata[pointer:(pointer+4)])[0]
        pointer +=4
        # read height ( 4 bytes )
        im_type = struct.unpack('<L',imagedata[pointer:(pointer+4)])[0]
        pointer +=4


        image_size = width*height*4

        image_bytes = imagedata[pointer:(pointer+image_size)]

        #
        dt = np.dtype("uint8")
        #dt = dt.newbyteorder('>L')
        new_image =np.frombuffer(image_bytes,dtype=dt)

        new_image = np.reshape(new_image,(self._image_y,self._image_x,4)) # TODO: make this generic
        #images.append(np.array(image_result))
        #print images[0].shape
        pointer += image_size



        return new_image,im_type,pointer


    def receive_data(self):

        depths = []

        #  First we get the message of the google protol
        capture_time = time.time()
        try:
            data  = get_message(self._socket)
        except:
            raise
        measurements = Measurements()
        measurements.ParseFromString(data)
        
        player_measures = measurements.player_measurements
        non_player_agents = measurements.non_player_agents
        image_data = ImageData()
        #print (self._image_x,self._image_y)
        try:
            logging.debug(" Trying to get the image")
            imagedata  = get_message(self._socket)
        except:
            raise




        pointer = 0
        while pointer < len(imagedata):
            image,im_type,pointer = self._read_image(imagedata,pointer)
            if im_type == 0:

                image_data.raw_rgb.append(image)
                logging.debug("RECEIVED rgb_raw")
            if im_type == 1:

                image_data.rgb.append(image)
                logging.debug("RECEIVED rgb")
            if im_type == 2:

                image_data.depth.append(image)
                logging.debug("RECEIVED depht")
            if im_type == 3:

                image_data.scene_seg.append(image)
                logging.debug("RECEIVED scene_seg")

       

        return [measurements.platform_timestamp,measurements.game_timestamp,player_measures,non_player_agents,image_data]


    def get_the_latest_data(self):

        try:
            data = self._data_buffer.get(timeout=5)

        except Empty:
            print("ERROR: No Data in 50 seconds, disconecting and reconecting from server ")
            self._running = False
            raise Empty

            
        
        else:
            self._data_buffer.task_done()
        finally:
            return data



    def start(self,socket):

        self._socket = socket

        self.run()
        

    def stop(self):
        self._running = False

    # We clean the buffer so that no old data is going to be used
    def clean(self):
        while True:
            try:
                aux=self._data_buffer.get(False)
            except Empty:
               
                return
      

    @threaded
    def run(self):
        try:
            while self._running:
                try:
                    self._data_buffer.put(self.receive_data(),timeout=20)
                except Full:
                    print ("ERROR: Queue Full for more than 20 seconds...")
                except Exception as e:
                    logging.debug("Some internal Socket error ")
                    logging.debug(e)
                    self._running = False
        except RuntimeError:
            print("Unexpected RuntimeError")
            self._running = False
        finally:
            logging.debug("We Are finishing the datastream thread ")

from __future__ import print_function
from carla import Carla
from carla import Control
from carla import Measurements

import numpy as np

from PIL import Image
import random
import time
import sys
import argparse
import logging



def print_pack(wall_time,game_time,measurements,agents,image,i):

	#image = image[:, :, ::-1]
	image_result = Image.fromarray(image)

	b, g, r,a = image_result.split()
	image_result = Image.merge("RGBA", (r, g, b,a))
	image_result.save('image' + str(i) + '.png')
	print ('Pack ',i)
	print ('	Measurements ')
	print ('		',measurements.forward_speed)
	print ('	Agents ',len(agents))
	for agent in agents:

		print ('		pos (%f,%f,%f) ' % (agent.transform.location.x,agent.transform.location.y,agent.transform.location.z))

	#print ('	',agents.forward_speed)



def use_example(ini_file,port = 2000, host ='127.0.0.1'):

	

	run_experiments = True
	while run_experiments:


		carla =Carla(host,port)

		
		positions = carla.requestNewEpisode(ini_file)

		carla.newEpisode(0)



		capture = time.time()

		i = 1
		
		positions_it = 1

		while run_experiments:
			# Use input to get action, save inputs for later backprops ... etc.
			try:
				wall_time,game_time,measurements,agents,image_data = carla.getMeasurements()
				#print (data)


				rand = random.random()

				control = Control()
				control.throttle = 0.9
				control.steer = (rand * 2) - 1

				carla.sendCommand(control)
		
				
				print ('fps: ',1.0/(time.time() -capture))
				capture = time.time()
				i+=1
				#print ('i= ',i)
				if i % 100 ==0:
					
					print ("RESTART")
					positions = carla.requestNewEpisode(ini_file)
					if positions_it < len(positions):
						carla.newEpisode(positions_it)
						positions_it+=1
					else :
						carla.newEpisode(0)
						positions_it = 1

				print("Position: ",positions_it-1)


			except Exception as e:

				logging.debug('exception: %s', e)
				time.sleep(1)




	
	
if __name__ == "__main__" :
	parser = argparse.ArgumentParser(description='Run multiple servers on multiple GPUs')
	parser.add_argument('host', metavar='HOST', type=str, help='host to connect to')
	parser.add_argument('port', metavar='PORT', type=int, help='port to connect to')

	parser.add_argument("-c", "--config", help="the path for the server config file that the client sends",type=str,default="CarlaSettings.ini") 


	parser.add_argument("-l", "--log", help="activate the log file",action="store_true") 
	parser.add_argument("-lv", "--log_verbose", help="put the log file to screen",action="store_true") 
	args = parser.parse_args()
	if args.log or args.log_verbose:
		LOG_FILENAME = 'log_manual_control.log'
		logging.basicConfig(filename=LOG_FILENAME,level=logging.DEBUG)
		if args.log_verbose:  # set of functions to put the logging to screen


			root = logging.getLogger()
			root.setLevel(logging.DEBUG)
			ch = logging.StreamHandler(sys.stdout)
			ch.setLevel(logging.DEBUG)
			formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
			ch.setFormatter(formatter)
			root.addHandler(ch)



	use_example(args.config,port=args.port, host=args.host)
